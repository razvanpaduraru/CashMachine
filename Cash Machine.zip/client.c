#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h> 
#include <unistd.h>
#include <fcntl.h>

#define BUFLEN 256

void error(char *msg)
{
    perror(msg);
    exit(0);
}

int main(int argc, char *argv[])
{
    int sockfd, n, sock_UDP;
    struct sockaddr_in serv_addr, udp_adr;
    struct hostent *server;
    fd_set read_fds;    //multimea de citire folosita in select()
    fd_set tmp_fds; //multime folosita temporar
    int fdmax;

    char buffer[BUFLEN];
    if (argc < 3) {
       fprintf(stderr,"Usage %s server_address server_port\n", argv[0]);
       exit(0);
    }
    //golim multimea de deori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);
    
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) 
        error("ERROR opening TCP socket");

    sock_UDP = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_UDP < 0) 
        error("ERROR opening UDP socket");
    
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &serv_addr.sin_addr);
    
    memset((char *) &udp_adr, 0, sizeof(udp_adr));
    udp_adr.sin_family = AF_INET;
    udp_adr.sin_port = htons(atoi(argv[2]));
    inet_aton(argv[1], &udp_adr.sin_addr);
    
    if (connect(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr)) < 0) 
        error("ERROR connecting");    
    //adaugam noul file deor (socketul pe care se asculta conexiuni) in multimea read_fds
    FD_SET(sockfd, &read_fds);
    FD_SET(sock_UDP, &read_fds);
    FD_SET(0, &read_fds);
    fdmax = sockfd;
    if (sock_UDP > sockfd) {
        fdmax = sock_UDP;
    }

    /* Crearea fisierului in care vom scrie operatiile realizate pentru client*/
    int pid = getpid();

    char nume[20];
    strcpy(nume, "client-");
    char pidc[10];
    sprintf(pidc, "%d", pid);
    strcat(nume, pidc);
    strcat(nume, ".log");
    int fdCl;
    fdCl = creat(nume, 0644);
    char lastlog[10];
    char copie[256];
    while(1) {
                
        tmp_fds = read_fds;
        if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
            error("ERROR in select");

        if (FD_ISSET(0, &tmp_fds)) {
            memset(buffer, 0 , BUFLEN);
            //citesc de la tastatura

            fgets(buffer, BUFLEN-1, stdin);
            
            strcpy(copie, buffer);
            if (strstr(copie, "login") != NULL) {
                char *sp = strtok(copie, " ");
                sp = strtok(NULL, " ");
                strcpy(lastlog, sp);
            }

            if (strstr(buffer, "quit") != NULL) {
                /*
                 Pentru operatia quit vom trimite mesajul catre
                server, pentru a deloga, daca este cazul, user-ul
                ramas logat pe acest client. Dupa aceasta vom inchide
                acest client.
                */
                n = send(sockfd,buffer,strlen(buffer), 0);    
                write(fdCl, "quit", strlen("quit"));
                write(fdCl, "\n", strlen("\n"));
                close(fdCl);
                close(sockfd);
                close(sock_UDP);
                exit(0);
            }

            if (strstr(buffer, "unlock") != NULL || (strstr(buffer, "login") == NULL && strstr(buffer, "logout") == NULL && strstr(buffer, "listsold") == NULL && strstr(buffer, "transfer") == NULL && strstr(buffer, "y") == NULL && strlen(buffer) != 1)) {
                copie[strlen(copie) - 1] = ' ';
                strcat(copie, lastlog);
                n = sendto(sock_UDP, copie, strlen(copie), 0, (struct sockaddr*) &udp_adr, sizeof(struct sockaddr));
                memset(copie, 0, 256);   
                write(fdCl, "unlock", strlen("unlock"));
                write(fdCl, "\n", strlen("\n"));
            } else {
                /*
             Pentru celelalte operatii vom trimite comanda
            iar serverul va face operatiile necesare
            */
                write(fdCl, buffer, strlen(buffer));
                n = send(sockfd,buffer,strlen(buffer), 0);
            }  
        }

        if (FD_ISSET(sock_UDP, &tmp_fds)) {
            memset(buffer, 0 , BUFLEN);
            struct sockaddr_in adr;
            int lenAd = sizeof(adr);
            int nUDP = recvfrom(sock_UDP, buffer, sizeof(buffer), 0, (struct sockaddr*) &adr, &lenAd);
            if (nUDP > 0) {
                write(fdCl, buffer, strlen(buffer));
                printf("%s \n", buffer);
                write(fdCl, "\n", strlen("\n"));
                write(fdCl, "\n", strlen("\n"));
                printf("\n");
                memset(buffer, 0 , BUFLEN);
            }
        }

        if (FD_ISSET(sockfd, &tmp_fds)) {
            memset(buffer, 0 , BUFLEN);
            //citesc de la tastatur
            n = recv(sockfd, buffer, sizeof(buffer), 0);
            if(n > 0) {
                /*
                 Daca am primit ceva, voi afisa mesajul prelucrat
                la tastatura si in fisier.
                */
                write(fdCl, buffer, strlen(buffer));
                printf("%s \n", buffer);
                write(fdCl, "\n", strlen("\n"));
                write(fdCl, "\n", strlen("\n"));
                printf("\n");
                memset(buffer, 0 , BUFLEN);
            } else {
                /*
                 Daca nu primesc ceva, inseamna ca serverul a fost inchis
                */
                printf("Server-ul s-a inchis!! \n");
                close(sockfd);
                exit(0);
            }
            memset(buffer, 0 , BUFLEN);
        }
    }
    close(sockfd);
    close(sock_UDP);

    return 0;
}