#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX_CLIENTS 5
#define BUFLEN 256

/* Structura ce defineste un utilizator*/
typedef struct {
    char nume[12];
    char prenume[12];
    int numar_card;
    int pin;
    int blocat; // este sau nu blocat
    int numarLogariNereusite; // numar de incercari de logare nereusite
    char cod_secret[8];
    double sold;
    int conectat; // este sau nu conectat
    int socketCon; // socketul pe care s-a conectat
    int sockUDP;
} client;

/* 
    Structura definita pentru a tine evidenta de logari
    per client al unui user.
*/
typedef struct {
    int sock;
    int user;
    int incercari;
} clWrong;

/*
 Functie pentru a prelua datele utilizatorilor din fisierul
de intrare dat ca parametru.
*/
client* getInput(FILE * fd, client *clienti, int numarClienti) {

    for (int i = 0; i < numarClienti; ++i) {
        client cl;

        fscanf(fd, "%s", cl.nume);
        fscanf(fd, "%s", cl.prenume);
        fscanf(fd, "%d", &cl.numar_card);
        fscanf(fd, "%d", &cl.pin);
        fscanf(fd, "%s", cl.cod_secret);
        fscanf(fd, "%lf", &cl.sold);
        cl.blocat = 0;
        cl.numarLogariNereusite = 0;
        cl.conectat = 0;
        cl.socketCon = 0;
        memcpy(&clienti[i], &cl, sizeof(cl));
        memset(&cl, 0, sizeof(cl));
    }

    return clienti;
}

/*
    Functie definita pentru verificarea operatiei primite
    de la client.
*/

void error(char *msg)
{
    perror(msg);
    exit(1);
}

int nrcard;
double suma;

int main(int argc, char *argv[])
{
     FILE * fd = fopen(argv[2], "r");

     int numarClienti;
     fscanf(fd, "%d", &numarClienti);
     client clienti[numarClienti];
     clWrong greseli[MAX_CLIENTS * numarClienti];
     getInput(fd, clienti, numarClienti);

     int max = 0;
     int ix = 0;
     while (ix < MAX_CLIENTS * numarClienti) {
        while (max < MAX_CLIENTS) {
            greseli[ix + max].sock = 0;
            greseli[ix + max].user = clienti[ix % numarClienti].numar_card;
            greseli[ix + max].incercari = 0;
            max ++;
        }
        max = 0;
        ix = ix + 5;
     }

     int sockfd, newsockfd, portno, clilen, sock_UDP;
     char buffer[BUFLEN];
     struct sockaddr_in serv_addr, cli_addr, udp_addr;
     int n, i, j;

     fd_set read_fds;   //multimea de citire folosita in select()
     fd_set tmp_fds;    //multime folosita temporar 
     int fdmax;     //valoare maxima file deor din multimea read_fds

     if (argc < 2) {
         fprintf(stderr,"Usage : %s port\n", argv[0]);
         exit(1);
     }

     //golim multimea de deori de citire (read_fds) si multimea tmp_fds 
     FD_ZERO(&read_fds);
     FD_ZERO(&tmp_fds);
     
     sock_UDP = socket(AF_INET, SOCK_DGRAM, 0);
     if (sock_UDP < 0) 
        error("ERROR opening UDP socket");

     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening TCP socket");
     
     portno = atoi(argv[1]);

     memset((char *) &udp_addr, 0, sizeof(udp_addr));
     udp_addr.sin_family = AF_INET;
     udp_addr.sin_addr.s_addr = htonl(INADDR_ANY);    // foloseste adresa IP a masinii
     udp_addr.sin_port = htons(portno);

     memset((char *) &serv_addr, 0, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;    // foloseste adresa IP a masinii
     serv_addr.sin_port = htons(portno);
     
     if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr)) < 0) 
              error("ERROR on binding");

     if (bind(sock_UDP, (struct sockaddr *) &udp_addr, sizeof(struct sockaddr_in)) < 0) 
              error("ERROR on binding");
     
     listen(sockfd, MAX_CLIENTS);

     //adaugam noul file deor (socketul pe care se asculta conexiuni) in multimea read_fds
     FD_SET(sockfd, &read_fds);
     FD_SET(sock_UDP, &read_fds);
     FD_SET(0, &read_fds);
     fdmax = sockfd;
     if (fdmax < sock_UDP) {
        fdmax = sock_UDP;
     }

    struct sockaddr_in adr;
    int lenAd = sizeof(adr);
    char lastComand[10];
    memset(lastComand, 0, sizeof(lastComand));
     // main loop
    while (1) {
        tmp_fds = read_fds; 
        if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
            error("ERROR in select");
    
        for(i = 0; i <= fdmax; i++) {
            if (FD_ISSET(i, &tmp_fds)) {

                if (i == 0) {
                    char buff[256];
                    fgets(buff, 255, stdin);
                    exit(0);
                }

                if (i == sock_UDP) {
                    memset(buffer, 0, BUFLEN);
            
                    memset((char *) &adr, 0, lenAd);
                    int nUDP = recvfrom(i, buffer, sizeof(buffer), 0, (struct sockaddr*) &adr, &lenAd);

                    int verif = 7;
                    char comm[100];
                    strcpy(comm, buffer);

                    char *p = strtok(comm, " \n\0");
                    strcpy(lastComand, comm);

                    if (strstr(comm, "unlock") != NULL) {
                        verif = -2;
                    }

                    char parola[8];
                    if (verif == -2) {
                        char *p = strtok(buffer, " ");
                        p = strtok(NULL, " ");
                        for (int j = 0; j < numarClienti; ++j) {
                            if (clienti[j].numar_card != atoi(p) && j == numarClienti - 1) {
                                char failCard[100] = "UNLOCK> -4 : Numar card inexistent";
                                sendto(i, failCard, strlen(failCard), 0, (struct sockaddr*) &adr, lenAd);
                                memset(failCard, 0, 100);
                                break;
                            }

                            if (clienti[j].numar_card == atoi(p)) {
                                clienti[j].sockUDP = i;
                                if (clienti[j].blocat) {
                                    strcpy(parola, clienti[j].cod_secret);
                                char trim[200];
                                strcat(trim, "UNLOCK> Trimite parola secreta!");
                                sendto(i, trim, strlen(trim), 0, (struct sockaddr*) &adr, lenAd);
                                memset(trim, 0, 200);
                                memset(parola, 0, 8);                               
                                break;
                                } else {
                                    char trim[200];
                                    strcat(trim, "UNLOCK> -6 : Operatie esuata!");
                                    sendto(i, trim, strlen(trim), 0, (struct sockaddr*) &adr, lenAd);
                                    memset(parola, 0, 8);
                                    memset(trim, 0, 200);
                                    break;
                                }   
                            }
                        }
                    }
                }

                if (i == sockfd) {
                    // a venit ceva pe socketul inactiv(cel cu listen) = o noua conexiune
                    // actiunea serverului: accept()
                    clilen = sizeof(cli_addr);
                    if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) == -1) {
                        error("ERROR in accept");
                    } 
                    else {
                        //adaug noul socket intors de accept() la multimea deorilor de citire
                        FD_SET(newsockfd, &read_fds);
                        if (newsockfd > fdmax) { 
                            fdmax = newsockfd;
                        }
                    }
                } else {               
                    // am primit date pe unul din socketii cu care vorbesc cu clientii
                    //actiunea serverului: recv()
                    memset(buffer, 0, BUFLEN);
                    if ((n = recv(i, buffer, sizeof(buffer), 0)) <= 0) {
                        if (n == 0) {
                            //conexiunea s-a inchis
                            printf("Conexiunea cu socket-ul %d incheiata!\n", i);
                        } else {
                            error("ERROR in recv");
                        }
                        close(i); 
                        FD_CLR(i, &read_fds); // scoatem din multimea de citire socketul pe care 
                    } else { //recv intoarce >0
                        if (strlen(lastComand) == 0 || strstr(lastComand, "login") || strstr(lastComand, "logout") || strstr(lastComand, "listsold") || strstr(lastComand, "transfer") || strstr(lastComand, "y") || strlen(lastComand) == 1) {
                           int ver = 6;
                        
                            char comanda[30];
                            strcpy(comanda, buffer);
                            char *p = strtok(comanda, " \n\0");
                            strcpy(lastComand, p);
                            
                            if (strcmp(comanda, "login") == 0) {
                                ver = 1;
                            }

                            if (strcmp(comanda, "logout") == 0) {
                                ver = 2;
                            }

                            if (strcmp(comanda, "listsold") == 0) {
                                ver = 3;
                            }    

                            if (strcmp(comanda, "transfer") == 0) {
                                ver = 4;
                            }

                            if (strcmp(comanda, "y") == 0) {
                                ver = 5;
                            }

                            if (strcmp(comanda, "quit") == 0) {
                                ver = -1;
                            }    

                            if (ver == 1) { // operatie de login
                                char *p = strtok(buffer, " ");
                                p = strtok(NULL, " ");

                                for (int j = 0; j < numarClienti; ++j) {
                                    if (clienti[j].numar_card != atoi(p) && j == numarClienti - 1) {
                                        // daca am parcurs tot vectorul, inseamna ca nu exista user-ul
                                        char failCard[100] = "IBANK> -4 : Numar card inexistent";
                                        clienti[j].numarLogariNereusite += 1;
                                        send(i, failCard, sizeof(failCard), 0);
                                        memset(buffer, 0, BUFLEN);
                                        memset(failCard, 0, 100);
                                        break;
                                    }

                                    if (clienti[j].numar_card == atoi(p)) {
                                        // verificare validitate card
                                        for (int k = 0; k < MAX_CLIENTS * numarClienti; ++k) {
                                            if (greseli[k].sock == i && greseli[k].user != atoi(p)) {
                                                greseli[k].incercari = 0;
                                            }
                                        }
                                        // verificare daca cardul e blocat
                                        if (clienti[j].blocat == 1) {
                                            char blocatC[100] = "IBANK> -5 : Card blocat";
                                            send(i, blocatC, sizeof(blocatC), 0);
                                            memset(buffer, 0, BUFLEN);
                                            memset(blocatC, 0, 10);
                                            break;
                                        } else {
                                            p = strtok(NULL, " ");
                                            if (clienti[j].pin == atoi(p)) {
                                                // verificare validitate pin
                                                if (clienti[j].conectat == 1) {
                                                    char con[100] = "IBANK> −2 : Sesiune deja deschisa";
                                                    send(i, con, sizeof(con), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(con, 0, 100);
                                                    break;
                                                }
                                                if (clienti[j].blocat == 1) {
                                                    char blocatC[100] = "IBANK> -5 : Card blocat";
                                                    send(i, blocatC, sizeof(blocatC), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(blocatC, 0, 100);
                                                    break;
                                                } else {
                                                    clienti[j].conectat = 1;
                                                    clienti[j].socketCon = i;
                                                    clienti[j].sockUDP = sock_UDP;
                                                    clienti[j].numarLogariNereusite = 0;
                                                    char v[100] = "IBANK> Welcome ";
                                                    strcat(v, clienti[j].nume);
                                                    strcat(v, " ");
                                                    char success[200];
                                                    strcat(v, clienti[j].prenume);
                                                    strcat(success, v);
                                                    send(i, success, sizeof(success), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(success, 0, 200);
                                                    memset(v, 0, 100);
                                                    break;
                                                }
                                                
                                            } else {
                                                if (clienti[j].blocat == 1) {
                                                    char blocatC[100] = "IBANK> -5 : Card blocat";
                                                    send(i, blocatC, sizeof(blocatC), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(blocatC, 0, 100);
                                                    break;
                                                } else {
                                                    char failPin[100] = "IBANK> -3 : Pin gresit";
                                                    int succes = 0;
                                                    // verificare daca cardul este sau nu blocat si al numarului
                                                    // de incercari per client
                                                    for (int k = 0; k < MAX_CLIENTS * numarClienti; ++k) {
                                                        if (greseli[k].user == clienti[j].numar_card && greseli[k].sock == i) {
                                                            succes = 1;
                                                            greseli[k].incercari += 1;
                                                            if (greseli[k].incercari >= 3) {
                                                                clienti[j].blocat = 1;
                                                                char blocatC[100] = "IBANK> -5 : Card blocat";
                                                                send(i, blocatC, sizeof(blocatC), 0);    
                                                                memset(buffer, 0, BUFLEN);
                                                                memset(blocatC, 0, 100);
                                                                memset(failPin, 0, 100);
                                                                break;
                                                            } else {
                                                                send(i, failPin, sizeof(failPin), 0);
                                                                memset(buffer, 0, BUFLEN);
                                                                memset(failPin, 0, 100);
                                                                break;
                                                            }
                                                        }
                                                    }

                                                    if (succes == 0) {
                                                        for (int k = 0; k < MAX_CLIENTS * numarClienti; ++k) {
                                                            if (greseli[k].user == clienti[j].numar_card && greseli[k].sock == 0) {
                                                                greseli[k].sock = i;
                                                                greseli[k].incercari += 1;
                                                                if (greseli[k].incercari >= 3) {
                                                                    clienti[j].blocat = 1;
                                                                    char blocatC[100] = "IBANK> -5 : Card blocat";
                                                                    send(i, blocatC, sizeof(blocatC), 0);    
                                                                    memset(buffer, 0, BUFLEN);
                                                                    memset(blocatC, 0, 100);
                                                                    break;
                                                                } else {
                                                                    send(i, failPin, sizeof(failPin), 0);
                                                                    memset(buffer, 0, BUFLEN);
                                                                    memset(failPin, 0, 100);
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                        
                                    }  
                                }
                            }

                            if (ver == 2) { // caz de logout
                                int poz = -1;
                                for (int j = 0; j < numarClienti; ++j) { 
                                    if (clienti[j].socketCon == i && clienti[j].conectat == 1) {
                                        poz = j;
                                    }
                                }
                                if (poz != -1) {
                                    clienti[poz].conectat = 0;
                                    ver = 0;
                                    char logoutVer[100] = "IBANK> Clientul a fost deconectat";
                                    send(i, logoutVer, sizeof(logoutVer), 0);
                                    memset(buffer, 0, BUFLEN);
                                    memset(logoutVer, 0, 100);
                                    break;
                                } else if (poz == -1) {
                                    ver = 0;
                                    char logoutNon[100] = "IBANK> −1 : Clientul nu este autentificat";
                                    send(i, logoutNon, sizeof(logoutNon), 0);
                                    memset(buffer, 0, BUFLEN);
                                    memset(logoutNon, 0, 100);
                                    break;
                                }
                            }

                            if (ver == 3) { // caz de listsold
                                int poz = -1;
                                for (int j = 0; j < numarClienti; ++j) { 
                                    if (clienti[j].socketCon == i && clienti[j].conectat == 1) {
                                        poz = j;
                                    }
                                }
                                if (poz != -1) {
                                    char rez[100];
                                    strcat(rez, "IBANK> ");
                                    char rez1[10];
                                    sprintf(rez1, "%.2lf", clienti[poz].sold);
                                    strcat(rez, rez1);
                                    send(i, rez, sizeof(rez), 0);
                                    memset(buffer, 0, BUFLEN);
                                    memset(rez, 0, 100);
                                    memset(rez1, 0, 10);
                                    break;
                                } else if (poz == -1) {
                                    char rez2[100] = "IBANK> −1 : Clientul nu este autentificat";
                                    send(i, rez2, sizeof(rez2), 0);
                                    memset(buffer, 0, BUFLEN);
                                    memset(rez2, 0, 100);
                                    break;
                                }
                            }

                            if (ver == 4) { // caz de transfer
                                char *p = strtok(buffer, " ");
                                p = strtok(NULL, " ");
                                nrcard = atoi(p);
                                p = strtok(NULL, " ");
                                suma = atof(p);

                                for (int j = 0; j < numarClienti; ++j) {
                                    if (clienti[j].socketCon == i && clienti[j].conectat == 1) {
                                        for (int k = 0; k < numarClienti; ++k) {
                                            if (clienti[k].numar_card != nrcard && k == numarClienti - 1) {
                                                char inex[100] = "IBANK> −4 : Numar card inexistent";
                                                send(i, inex, sizeof(inex), 0);
                                                memset(buffer, 0, BUFLEN);
                                                memset(inex, 0, 100);
                                                break;
                                            }

                                            if (clienti[k].numar_card == nrcard) {
                                                if (clienti[j].sold > suma) {
                                                    char rez[200];
                                                    strcat(rez, "IBANK> Transfer ");
                                                    char rezS[10];
                                                    sprintf(rezS, "%.2lf", suma);
                                                    strcat(rez, rezS);
                                                    strcat(rez, " catre ");
                                                    strcat(rez, clienti[k].nume);
                                                    strcat(rez, " ");
                                                    strcat(rez, clienti[k].prenume);
                                                    strcat(rez, "? [y/n]");

                                                    send(i, rez, sizeof(rez), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(rez, 0, 100);
                                                    memset(rezS, 0, 10);
                                                    break;                                                
                                                } else {
                                                    char insuf[100] = "IBANK> −8 : Fonduri insuficiente";
                                                    send(i, insuf, sizeof(insuf), 0);
                                                    memset(buffer, 0, BUFLEN);
                                                    memset(insuf, 0, 100);
                                                    break;
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }

                            if (ver == 6) { // caz pentru dorirea anularii operatiei de transfer
                                char opAn[100] = "IBANK> −9 : Operatie anulata";
                                send(i, opAn, sizeof(opAn), 0);
                                memset(buffer, 0, BUFLEN);
                                memset(opAn, 0, 100);
                            }

                            if (ver == 5) { // caz pentru acceptarea operatiei de transfer
                                 for (int j = 0; j < numarClienti; ++j) {
                                    if (clienti[j].socketCon == i && clienti[j].conectat == 1) {
                                       for (int k = 0; k < numarClienti; ++k) {
                                           if (clienti[k].numar_card == nrcard) {
                                               clienti[j].sold -= suma;
                                               clienti[k].sold += suma;
                                               char succ[100] = "IBANK> Transfer realizat cu succes";
                                               send(i, succ, sizeof(succ), 0);
                                               memset(buffer, 0, BUFLEN);
                                               memset(succ, 0, 100);
                                               break;
                                            }
                                        }
                                        break;
                                    }
                                }
                            }

                            if (ver == -1) { // delogarea utilizatorilor in caz de quit de la client
                                for (int j = 0; j < numarClienti; ++j) {
                                    if (clienti[j].socketCon == i && clienti[j].conectat == 1) {
                                        clienti[j].conectat = 0;
                                    }
                                }
                            } 
                        } else {
                            int nrcdr;
                            char parola[8];
                            char *p = strtok(buffer, " \n\0");
                            strcpy(parola, p);
                            p = strtok(NULL, " \n\0");
                            nrcdr = atoi(p);

                            for (int j = 0; j < numarClienti; ++j) {
                                if (clienti[j].numar_card == nrcdr) {
                                    if (strcmp(parola, clienti[j].cod_secret) == 0) {
                                        char trim[200];
                                        strcat(trim, "UNLOCK> Card deblocat");
                                        strcpy(lastComand, "login");
                                        clienti[j].blocat = 0;
                                        for (int k = 0; k < MAX_CLIENTS * numarClienti; ++k) {
                                            if (greseli[k].user == clienti[j].numar_card) {
                                                greseli[k].incercari = 0;
                                            }
                                        }
                                        sendto(sock_UDP, trim, strlen(trim), 0, (struct sockaddr*) &adr, lenAd);
                                        memset(parola, 0, 8);
                                        memset(trim, 0, 200);
                                        break;
                                    } else {
                                        char trim[200];
                                        strcat(trim, "UNLOCK> -7 : Deblocare e suata");
                                        sendto(sock_UDP, trim, strlen(trim), 0, (struct sockaddr*) &adr, lenAd);
                                        memset(parola, 0, 8);
                                        memset(trim, 0, 200);
                                        break;
                                    }
                                }
                            }
                        }

                        
                    }
                } 
            }
        }
     }

     close(sockfd);
   
     return 0; 
}